"use strict";
exports.__esModule = true;
var Seller_1 = require("./Seller");
console.log(Seller_1.sellerEmail);
(0, Seller_1.display)();
var sellerObj = new Seller_1.Seller();
console.log(sellerObj.sellerId);
console.log(sellerObj.sellerName);
