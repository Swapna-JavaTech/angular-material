var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ValidationType;
(function (ValidationType) {
    ValidationType[ValidationType["NotNull"] = 0] = "NotNull";
})(ValidationType || (ValidationType = {}));
function validate() {
    var types = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        types[_i] = arguments[_i];
    }
    return function (target, propertyKey) {
    };
}
var Validator2 = /** @class */ (function () {
    function Validator2() {
    }
    //todo  add more validator maps
    Validator2.registerValidators = function (target, property, types) {
        for (var _i = 0, types_1 = types; _i < types_1.length; _i++) {
            var type = types_1[_i];
            if (type == ValidationType.NotNull) {
                var keys = this.notNullValidatorMap.get(target);
                if (!keys) {
                    keys = [];
                    this.notNullValidatorMap.set(target, keys);
                }
                keys.push(property);
            }
        }
    };
    Validator2.validate = function (target) {
        var notNullProps = this.notNullValidatorMap.get(Object.getPrototypeOf(target));
        if (!notNullProps) {
            return true;
        }
        var hasErrors = false;
        for (var _i = 0, notNullProps_1 = notNullProps; _i < notNullProps_1.length; _i++) {
            var property = notNullProps_1[_i];
            var value = target(property);
            if (!value) {
                console.error(property + "value cannot be null");
                hasErrors = true;
            }
        }
        return hasErrors;
    };
    Validator2.notNullValidatorMap = new Map();
    return Validator2;
}());
var Employee = /** @class */ (function () {
    function Employee(name) {
        this.empName = '';
        this.empName = name;
    }
    __decorate([
        validate(ValidationType.NotNull)
    ], Employee.prototype, "empName");
    return Employee;
}());
console.log("---creating an instance of Employee class....");
var emp = new Employee(null);
console.log(emp);
var val = Validator2.validate(emp);
console.log("validation passed = " + !val);
console.log("---creating an another instance of Employee class....");
var emp1 = new Employee("Tina");
console.log(emp1);
var val1 = Validator2.validate(emp1);
console.log("validation passed = " + !val1);
