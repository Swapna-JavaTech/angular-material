// without generics

function getArray(data : any[]) : any[]{
    return new Array().concat(data);

}

let result = getArray([200,400,220]);
result.push(700);//ok

let result1 = getArray(["Hello","Hi","Bye"]);
result1.push("Welcome");//ok


console.log(result1);
console.log(result);

//with generics
function getArray1<T>(data : T[]) : T[]{
    return new Array<T>().concat(data);
}

let resultGenerics = getArray1<number>([200,400,220]);
resultGenerics.push(700);//ok
resultGenerics.push("welcome");//ok

let resultGenerics1 = getArray1<string>(["Hello","Hi","Bye"]);
resultGenerics1.push("Welcome");//ok
resultGenerics1.push(300);//ok

console.log(resultGenerics);
console.log(resultGenerics1);