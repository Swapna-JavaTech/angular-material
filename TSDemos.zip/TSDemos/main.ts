enum ValidationType{
    NotNull
}

function validate(...types:ValidationType[]){
    return function(target:any,propertyKey:string){
        Validator2.registerValidators(target,propertyKey,types);
    }
}

class Validator2{
    private static notNullValidatorMap:Map<any,string[]>=new Map();
    //todo  add more validator maps
    static registerValidators(target:any,property:any,types:ValidationType[]):void{
        for(const type of types){
            if(type == ValidationType.NotNull){
                let keys :string[] = this.notNullValidatorMap.get(target)!;
                if(!keys){
                    keys = [];
                    this.notNullValidatorMap.set(target,keys);
                }
                keys.push(property);
            }
        }
    }

    static validate(target:any):boolean{
        let notNullProps:string[] = this.notNullValidatorMap.get(Object.getPrototypeOf(target))!;
        if(!notNullProps){
            return true;
        }
        let hasErrors : boolean = false;
        for(const property of notNullProps){
            let value = target(property);
            if(!value){
                console.error(property + "value cannot be null");
                hasErrors = true;
            }
        }
        return hasErrors;
    }
}

class Employee{

    @validate(ValidationType.NotNull)
    empName:string ='';
    constructor(name:any){
        this.empName = name;
    }
}

console.log("---creating an instance of Employee class....");
let emp :Employee = new Employee(null);
console.log(emp);
let val = Validator2.validate(emp);
console.log("validation passed = " + !val);

console.log("---creating an another instance of Employee class....");
let emp1 :Employee = new Employee("Tina");
console.log(emp1);
let val1 = Validator2.validate(emp1);
console.log("validation passed = " + !val1);
