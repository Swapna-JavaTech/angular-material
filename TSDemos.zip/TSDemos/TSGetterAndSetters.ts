const fullNameMaxLength = 10;
class Customer{
    private fullName!: string;

    public getFullName(): string {
        return this.fullName;
    }

    public setFullName(fullName: string): void {
        this.fullName = fullName;
    }
}