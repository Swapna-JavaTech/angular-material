import { display, Seller, sellerEmail } from "./Seller";

console.log(sellerEmail);

display();

let sellerObj = new Seller();
console.log(sellerObj.sellerId);
console.log(sellerObj.sellerName);