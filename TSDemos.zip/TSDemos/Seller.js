"use strict";
exports.__esModule = true;
exports.Seller = exports.display = exports.sellerEmail = void 0;
exports.sellerEmail = "rerr@gmail.com";
function display() {
    console.log(exports.sellerEmail);
}
exports.display = display;
var Seller = /** @class */ (function () {
    function Seller() {
        this.sellerId = 3450;
        this.sellerName = "ttttt";
    }
    Seller.prototype.displaySellerDetails = function () {
        console.log(this.sellerId + "   " + this.sellerName);
    };
    return Seller;
}());
exports.Seller = Seller;
