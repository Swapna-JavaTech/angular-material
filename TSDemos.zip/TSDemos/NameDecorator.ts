@sealed
class Student{

}

function sealed(target:Function){
    Object.seal(target);
    Object.seal(target.prototype)
}

const decoratorA = (someParam:boolean) =>{
    return (target : Function) =>{

    }
}

@decoratorA(false)
class Student1{

}