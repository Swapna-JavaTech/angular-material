export  let sellerEmail = "rerr@gmail.com";

export function display(){
    console.log(sellerEmail);
}

export class Seller{
    sellerId : number =3450;
    sellerName : string  = "ttttt";

    displaySellerDetails(){
        console.log(this.sellerId + "   " + this.sellerName)
    }
}