interface IStudent{

    studentName : string;
    studentMarks : number;
    getStudentDetails():string;
    displayResults : (arg0: string) => string;
}

class StudentInfo implements IStudent{
    studentName: string = "";
    studentMarks: number = 0;
    
    getStudentDetails(): string {
        throw new Error("Method not implemented.");
    }
    displayResults!: (arg0: string) => string;
    
}