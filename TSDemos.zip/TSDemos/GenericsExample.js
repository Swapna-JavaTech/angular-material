// without generics
function getArray(data) {
    return new Array().concat(data);
}
var result = getArray([200, 400, 220]);
result.push(700); //ok
var result1 = getArray(["Hello", "Hi", "Bye"]);
result1.push("Welcome"); //ok
console.log(result1);
console.log(result);
//with generics
function getArray1(data) {
    return new Array().concat(data);
}
var resultGenerics = getArray1([200, 400, 220]);
result.push(700); //ok
result.push("welcome"); //ok
var resultGenerics1 = getArray1(["Hello", "Hi", "Bye"]);
result1.push("Welcome"); //ok
result1.push(300); //ok
